<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Analytics extends Model
{
    protected $guarded = ['id'];
    public $timestamps = false;
}
